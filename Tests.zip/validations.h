#include <iostream>

using namespace std;

int cinint();

double cindouble();

void wait();