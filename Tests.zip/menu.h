#include <string>

using namespace std;

void menu_vinos(string extra=""); // function prototype for add.h -- don't forget the semicolon!
void menu(string extra="");

void menu_pedidos(string extra="");

void menu_tipos_vinos(string extra="");

void menu_clientes(string extra="");